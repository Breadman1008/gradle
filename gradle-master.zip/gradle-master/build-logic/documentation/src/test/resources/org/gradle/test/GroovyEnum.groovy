package org.gradle.test

public enum GroovyEnum {
    A, B
}
